# 🎬 Bollyflix Android App

Cette application Android native a été développée en **Kotlin** avec **Jetpack Compose** pour offrir une expérience de streaming fluide et moderne, connectée directement à l'API Supabase de Bollyflix.

## 🚀 Fonctionnalités incluses

- **Interface Moderne** : Développée avec Jetpack Compose pour une fluidité maximale.
- **Navigation Intuitive** : Accueil avec bannières "À la une", sections "Bollywood" et "Action".
- **Lecteur Vidéo Premium** : Intégration d'ExoPlayer (Media3) supportant les flux HLS (m3u8) et MP4.
- **Gestion des Détails** : Page dédiée pour chaque film/série avec synopsis, année et labels.
- **Authentification** : Système complet de Login/SignUp via Supabase Auth.
- **Identité Visuelle** : Icône personnalisée et Splash Screen basés sur le logo fourni.

## 🛠 Architecture Technique

- **Langage** : Kotlin
- **UI Framework** : Jetpack Compose
- **Architecture** : MVVM (Model-View-ViewModel)
- **Réseau** : Retrofit + OkHttp (avec injection automatique de l'Anon Key)
- **Image Loading** : Coil
- **Video Player** : ExoPlayer (Media3)

## 📦 Instructions pour le Build Final

Le code source fourni est prêt à être ouvert dans **Android Studio**.

1.  Ouvrez le dossier `bollyflix` dans Android Studio.
2.  Laissez Gradle synchroniser les dépendances.
3.  Pour générer l'APK final : `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4.  L'APK sera généré dans `app/build/outputs/apk/debug/`.

## 🔑 Configuration API

Les clés API sont déjà configurées dans `com.bollyflix.app.util.Constants.kt`.
- **Base URL** : https://wxqnldzzbculxejsigyz.supabase.co/rest/v1/
- **Anon Key** : [CONFIGURÉE]

---
*Développé avec passion pour Bollyflix.*
