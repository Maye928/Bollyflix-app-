package com.bollyflix.app.data.remote

import com.bollyflix.app.util.Constants
import okhttp3.Interceptor
import okhttp3.Response

class SupabaseInterceptor(private val authToken: String? = null) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val requestBuilder = originalRequest.newBuilder()
            .addHeader("apikey", Constants.ANON_KEY)
            .addHeader("Authorization", "Bearer ${authToken ?: Constants.ANON_KEY}")
            .addHeader("Content-Type", "application/json")
        
        return chain.proceed(requestBuilder.build())
    }
}
