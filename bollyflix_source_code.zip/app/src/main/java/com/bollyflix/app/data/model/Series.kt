package com.bollyflix.app.data.model

import com.google.gson.annotations.SerializedName

data class Series(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?,
    @SerializedName("thumbnail_url") val thumbnailUrl: String,
    @SerializedName("banner_url") val bannerUrl: String,
    @SerializedName("genre") val genre: String,
    @SerializedName("year") val year: Int?,
    @SerializedName("is_featured") val isFeatured: Boolean,
    @SerializedName("is_popular") val isPopular: Boolean,
    @SerializedName("is_new") val isNew: Boolean,
    @SerializedName("labels") val labels: List<String>?,
    @SerializedName("created_at") val createdAt: String
)

data class Episode(
    @SerializedName("id") val id: String,
    @SerializedName("series_id") val seriesId: String,
    @SerializedName("title") val title: String,
    @SerializedName("episode_number") val episodeNumber: Int,
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("video_url") val videoUrl: String,
    @SerializedName("thumbnail_url") val thumbnailUrl: String?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("labels") val labels: List<String>?,
    @SerializedName("created_at") val createdAt: String
)
