package com.bollyflix.app.util

object Constants {
    const val BASE_URL = "https://wxqnldzzbculxejsigyz.supabase.co/rest/v1/"
    const val AUTH_URL = "https://wxqnldzzbculxejsigyz.supabase.co/auth/v1/"
    const val ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind4cW5sZHp6YmN1bHhlanNpZ3l6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcyODE1MjAsImV4cCI6MjA4Mjg1NzUyMH0.myoH773ELSXgnH4fVgqbnYLTkgaYewHoaaoY85tR80U"
    
    // Endpoints
    const val FILMS = "films"
    const val SERIES = "series"
    const val EPISODES = "episodes"
    const val LIVE_CHANNELS = "live_channels"
    const val LIVE_CATEGORIES = "live_categories"
}
