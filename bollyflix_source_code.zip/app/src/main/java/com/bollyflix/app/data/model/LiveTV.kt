package com.bollyflix.app.data.model

import com.google.gson.annotations.SerializedName

data class LiveChannel(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("logo_url") val logoUrl: String?,
    @SerializedName("stream_url") val streamUrl: String,
    @SerializedName("category_id") val categoryId: String?,
    @SerializedName("is_active") val isActive: Boolean,
    @SerializedName("channel_type") val channelType: String, // "stream" | "playlist"
    @SerializedName("created_at") val createdAt: String
)

data class LiveCategory(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String,
    @SerializedName("display_order") val displayOrder: Int,
    @SerializedName("is_visible") val isVisible: Boolean
)
