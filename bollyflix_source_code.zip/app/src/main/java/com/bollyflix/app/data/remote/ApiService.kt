package com.bollyflix.app.data.remote

import com.bollyflix.app.data.model.*
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    // Films
    @GET("films")
    suspend fun getFilms(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<Film>

    @GET("films")
    suspend fun getFeaturedFilms(
        @Query("is_featured") isFeatured: String = "eq.true",
        @Query("select") select: String = "*"
    ): List<Film>

    @GET("films")
    suspend fun getFilmsByGenre(
        @Query("genre") genre: String, // ex: "ilike.*Bollywood*"
        @Query("select") select: String = "*",
        @Query("limit") limit: Int = 10
    ): List<Film>

    // Séries
    @GET("series")
    suspend fun getSeries(
        @Query("select") select: String = "*",
        @Query("order") order: String = "updated_at.desc"
    ): List<Series>

    @GET("episodes")
    suspend fun getEpisodes(
        @Query("series_id") seriesId: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "season_number.asc,episode_number.asc"
    ): List<Episode>

    // Live TV
    @GET("live_categories")
    suspend fun getLiveCategories(
        @Query("is_visible") isVisible: String = "eq.true",
        @Query("select") select: String = "*",
        @Query("order") order: String = "display_order.asc"
    ): List<LiveCategory>

    @GET("live_channels")
    suspend fun getLiveChannels(
        @Query("is_active") isActive: String = "eq.true",
        @Query("select") select: String = "*",
        @Query("order") order: String = "name.asc"
    ): List<LiveChannel>
}
