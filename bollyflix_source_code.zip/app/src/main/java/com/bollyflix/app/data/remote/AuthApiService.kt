package com.bollyflix.app.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

data class AuthRequest(
    @SerializedName("email") val email: String,
    @SerializedName("password") val password: String
)

data class AuthResponse(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String,
    @SerializedName("expires_in") val expiresIn: Int,
    @SerializedName("refresh_token") val refreshToken: String,
    @SerializedName("user") val user: UserData
)

data class UserData(
    @SerializedName("id") val id: String,
    @SerializedName("email") val email: String
)

interface AuthApiService {
    @POST("signup")
    suspend fun signUp(@Body request: AuthRequest): UserData

    @POST("token")
    suspend fun login(
        @Query("grant_type") grantType: String = "password",
        @Body request: AuthRequest
    ): AuthResponse
}
