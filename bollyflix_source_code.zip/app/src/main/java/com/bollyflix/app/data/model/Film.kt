package com.bollyflix.app.data.model

import com.google.gson.annotations.SerializedName

data class Film(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?,
    @SerializedName("thumbnail_url") val thumbnailUrl: String,
    @SerializedName("banner_url") val bannerUrl: String,
    @SerializedName("video_url") val videoUrl: String,
    @SerializedName("genre") val genre: String,
    @SerializedName("year") val year: Int?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("is_featured") val isFeatured: Boolean,
    @SerializedName("is_popular") val isPopular: Boolean,
    @SerializedName("is_new") val isNew: Boolean,
    @SerializedName("labels") val labels: List<String>?,
    @SerializedName("created_at") val createdAt: String
)
